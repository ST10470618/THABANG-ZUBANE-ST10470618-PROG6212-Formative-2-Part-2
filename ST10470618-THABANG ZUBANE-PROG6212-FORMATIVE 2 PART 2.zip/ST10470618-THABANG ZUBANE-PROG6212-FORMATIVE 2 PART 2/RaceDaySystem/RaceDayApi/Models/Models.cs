﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RaceDayApi.Models
{
    //--1.USER TABLE--
    public class User
    {
        [Key] public int UserId { get; set; }
        [Required] public string FullName { get; set; } = string.Empty;
        [Required] public string Email { get; set; } = string.Empty;
        [Required] public string PasswordHash { get; set; } = string.Empty;
        private string role = string.Empty;

        public string GetRole()
        {
            return role;
        }

        public void SetRole(string value)
        {
            role = value;
        }

        public bool Role { get; internal set; }
        public string? PhoneNumber {  get; set; }
        public DateTime CreatedDate { get; set; } = DateTime.UtcNow;

        public ICollection<Event> OrganisedEvents { get; set; } = new List<Event>();
        public ICollection<Registration> Registrations { get; set; } = new List<Registration>();
    }

    //--2.VENUE TABLE--
    public class Venue
    {
        [Key] public int VenueId { get; set; }
        [Required] public string VenueName { get; set; } = string.Empty;
        [Required] public string Address { get; set; } = string.Empty;
        [Required] public string City { get; set; } = string.Empty;
        [Required] public string Province { get; set; } = string.Empty;
        public int Capacity { get; set; }

        public ICollection<Event> Events { get; set; } = new List<Event>();
    }

    //--3.EVENT TABLE--
    public class Event
    {
        [Key] public int EventId { get; set; }
        [Required] public string EventName { get; set; } = string.Empty;
        public DateTime EventDate { get; set; }
        public string? Description { get; set; }
        [Required] public string EventType {  get; set; } = "Run";

        [Required] public required string OrganiserId { get; set; }
        [ForeignKey("OrganiserId")] public User? Organiser { get; set; }

        [Required] public int VenueId { get; set; }
        [ForeignKey("VenueId")] public Venue? Venue { get; set; }

        public string status { get; set; } = "Upcoming";
        public ICollection<Category> Categories { get; set; } = new List<Category>();
    }

    //--4.CATEGORY TABLE--
    public class Category
    {
        [Key] public int CategoryId { get; set; }
        [Required] public int EventId { get; set; }
        [ForeignKey("EventId")] public Event? Event { get; set; }
        [Required] public string CategoryName { get; set; } = string.Empty;
        [Column(TypeName = "decimal(5,2")] public decimal DistanceKM { get; set; }
        [Column(TypeName = "decimal(10,2)")] public decimal EntryFee {  get; set; }
        public int MaxParticipants { get; set; }

        public ICollection<Registration> Registrations { get; set; } = new List<Registration>();
    }

    //--5.REGISTRATION TABLE--
    public class Registration
    {
        [Key] public int RegistrationId { get; set; }
        [Required] public int ParticipantId { get; set; }
        [ForeignKey("ParticipantId")] public User? Participant { get; set; }
        [Required] public int CategoryId { get; set; }
        [ForeignKey("CategoryId")] public Category? Category { get; set; }
        public DateTime RegistrationDate { get; set; } = DateTime.UtcNow;
        public string RegistrationStatus { get; set; } = "Pending";
        public int? RaceNumber { get; set; }

        public Payment? Payment { get; set; }
        public Result? Results { get; set; }
    }

    //--6.PAYMENT TABLE--
    public class Payment
    {
        [Key] public int PaymentId { get; set; }
        [Required] public int RegistrationId { get; set; }
        [ForeignKey("RegistrationId")] public Registration? Registration { get; set; }
        [Column(TypeName = "decimal(10,2)")] public decimal Amount { get; set; }
        public DateTime? PaymentDate { get; set; }
        public string PaymentStatus { get; set; } = "Pending";
        public string? PaymentReference { get; set; }
    }

    //--7.RESULT TABLE--
    public class Result
    {
        [Key] public int ResultId { get; set; }
        [Required] public int RegistrationId {  get; set; }
        [ForeignKey("RegistrationId")] public Registration? Registration { get; set; }
        public TimeSpan? FinishTime { get; set; }
        public int? Position { get; set; }
        public string ResultStatus { get; set; } = "Finished";
    }

    //--8.DATABASE CONTEXT--
    public class RaceDayDbContext : DbContext
    {
        public RaceDayDbContext(DbContextOptions<RaceDayDbContext> options) : base(options) { }

        public DbSet<User> Users => Set<User>();
        public DbSet<Venue> Venues => Set<Venue>();
        public DbSet<Event> Events => Set<Event>();
        public DbSet<Category> Categories => Set<Category>();
        public DbSet<Registration> Registrations => Set<Registration>();
        public DbSet<Payment> Payments => Set<Payment>();
        public DbSet<Result> Results => Set<Result>();

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<User>().HasIndex(u => u.Email).IsUnique();
            modelBuilder.Entity<Registration>().HasIndex(r => new {r.ParticipantId, r.CategoryId}).IsUnique();
        }
    }
}
